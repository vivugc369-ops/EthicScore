// Injects the shared nav and footer into any page that has
// <div id="site-nav"></div> and/or <div id="site-footer"></div>.
// Keeps every page's header/footer identical without a build step.
(function () {
  function inject(id, url) {
    var target = document.getElementById(id);
    if (!target) return;
    fetch(url)
      .then(function (res) { return res.ok ? res.text() : Promise.reject(res.status); })
      .then(function (html) { target.innerHTML = html; execScripts(target); })
      .catch(function () { /* fails quietly — page still works without nav chrome */ });
  }
  // innerHTML doesn't execute <script> tags, so re-create them manually.
  function execScripts(container) {
    container.querySelectorAll('script').forEach(function (old) {
      var s = document.createElement('script');
      if (old.src) { s.src = old.src; } else { s.textContent = old.textContent; }
      old.replaceWith(s);
    });
  }
  inject('site-nav', '/partials/nav.html');
  inject('site-footer', '/partials/footer.html');
})();
