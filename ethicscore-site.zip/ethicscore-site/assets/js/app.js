/* =============================================
   ETHICSCORE — APP LOGIC
   Requires assets/js/products.js loaded first
   (defines window.ETHIC_PRODUCTS).
   ============================================= */

const products = window.ETHIC_PRODUCTS || [];

let routine = JSON.parse(localStorage.getItem('cs_routine') || '[]');
let isPro = localStorage.getItem('cs_isPro') === 'true';
let activeCategory = 'all';

function saveState() {
  localStorage.setItem('cs_routine', JSON.stringify(routine));
  localStorage.setItem('cs_isPro', isPro);
}
function scoreClass(s) { if (s >= 75) return "high"; if (s >= 55) return "mid"; return "low"; }
function getRegionEmoji(r) { const map = { us: '🇺🇸', eu: '🇪🇺', in: '🇮🇳', jp: '🇯🇵' }; return map[r] || '🌍'; }

function openLightbox(src) {
  const lb = document.getElementById('imageLightbox');
  if (!lb) return;
  document.getElementById('lightboxImage').src = src;
  lb.classList.add('open');
  document.body.style.overflow = 'hidden';
}
function closeLightbox() {
  const lb = document.getElementById('imageLightbox');
  if (!lb) return;
  lb.classList.remove('open');
  document.body.style.overflow = '';
}
document.addEventListener('keydown', (e) => { if (e.key === 'Escape') { closeLightbox(); closeDetail(); } });

function renderProducts(list, targetId) {
  const container = document.getElementById(targetId);
  if (!container) return;
  if (list.length === 0) { container.innerHTML = '<div class="empty-state">🌿 No products found</div>'; return; }
  container.innerHTML = list.map((p) => `
    <div class="card" onclick="openDetail(${p.id})">
      <img src="${p.img}" alt="${p.name}" loading="lazy" onclick="event.stopPropagation(); openLightbox('${p.img}');" />
      <div class="card-info">
        <div class="brand">${p.brand} <span class="region-tag">${getRegionEmoji(p.region)} ${p.region.toUpperCase()}</span></div>
        <div class="name">${p.name}</div>
        <div class="price">${p.price}</div>
      </div>
      <div class="right-col">
        <div class="score ${scoreClass(p.score)}">${p.score}</div>
        <button class="add-btn ${routine.includes(p.id) ? 'added' : ''}" aria-label="${routine.includes(p.id) ? 'Remove from routine' : 'Add to routine'}" onclick="event.stopPropagation(); toggleRoutine(${p.id});">${routine.includes(p.id) ? '✓' : '+'}</button>
      </div>
    </div>
  `).join('');
}

function toggleRoutine(id) {
  const idx = routine.indexOf(id);
  if (idx > -1) routine.splice(idx, 1); else routine.push(id);
  saveState();
  const onRoutine = document.getElementById('routineView') && document.getElementById('routineView').style.display === 'block';
  if (onRoutine) renderRoutine(); else renderProducts(filteredProducts(), 'productList');
}

function filteredProducts() {
  const searchEl = document.getElementById('searchInput');
  const regionEl = document.getElementById('regionFilter');
  const q = searchEl ? searchEl.value.toLowerCase() : '';
  const region = regionEl ? regionEl.value : 'all';
  return products.filter(p => {
    const matchName = p.brand.toLowerCase().includes(q) || p.name.toLowerCase().includes(q);
    const matchRegion = region === 'all' || p.region === region;
    const matchCategory = activeCategory === 'all' || p.category === activeCategory;
    return matchName && matchRegion && matchCategory;
  });
}

function setCategory(cat, btn) {
  activeCategory = cat;
  document.querySelectorAll('.filter-chip').forEach(c => c.classList.remove('active'));
  if (btn) btn.classList.add('active');
  renderProducts(filteredProducts(), 'productList');
}

function renderRoutine() {
  const list = products.filter(p => routine.includes(p.id));
  const avgContainer = document.getElementById('avgContainer');
  if (!avgContainer) return;
  if (list.length === 0) {
    avgContainer.innerHTML = '';
    document.getElementById('routineList').innerHTML = '<div class="empty-state">🌱 No products in routine yet — add some from Discover</div>';
    document.getElementById('routineAnalyzer').innerHTML = '';
    return;
  }
  const avg = Math.round(list.reduce((s, p) => s + p.score, 0) / list.length);
  avgContainer.innerHTML = `<div class="avg-box"><div style="font-size:0.75rem;color:var(--text-faint);font-weight:600;">ROUTINE ETHICS AVG</div><div class="num">${avg}<span style="font-size:0.9rem;color:var(--text-faint);">/100</span></div><div style="font-size:0.8rem;color:var(--text-faint);">${list.length} products</div></div>`;
  renderProducts(list, 'routineList');
  analyzeRoutine(list);
}

function analyzeRoutine(list) {
  const analyzer = document.getElementById('routineAnalyzer');
  if (!analyzer) return;
  if (list.length === 0) { analyzer.innerHTML = ''; return; }
  const categories = list.map(p => p.category);
  let tips = [];
  if (!categories.includes('cleanser')) tips.push('🧼 Missing a cleanser');
  if (!categories.includes('serum')) tips.push('🧪 Add a serum');
  if (!categories.includes('moisturizer')) tips.push('💧 You need a moisturizer');
  if (!categories.includes('sunscreen')) tips.push("☀️ Don't forget sunscreen");
  if (!categories.includes('toner')) tips.push('🌸 Add a toner');
  if (!categories.includes('mask')) tips.push('🌿 Try a face mask');
  let html = `<div class="avg-box" style="background:rgba(155,191,143,0.03);"><div style="font-weight:700;color:var(--text);">🧠 Routine Tips</div>`;
  if (tips.length === 0) { html += `<p style="color:var(--sage);">✨ Perfect routine!</p>`; }
  else { html += tips.map(t => `<div style="padding:6px 0;color:var(--text-dim);font-size:0.9rem;">${t}</div>`).join(''); }
  html += `</div>`;
  analyzer.innerHTML = html;
}

function openDetail(id) {
  const p = products.find(x => x.id === id);
  if (!p) return;
  const overlay = document.getElementById('detailOverlay');
  const sheet = document.getElementById('detailSheet');
  if (!overlay || !sheet) return;
  const ingredientsHTML = isPro
    ? `<div style="margin-top:16px;font-weight:700;color:var(--text);">Ingredients <span class="pro-badge">PRO</span></div><div>${p.ingredients.map(i => `<span class="ingredient-chip">✓ ${i}</span>`).join('')}</div>`
    : `<div class="lock-overlay"><div class="lock-icon">🔒</div><p>Ingredients are Pro only</p><button class="upgrade-btn" onclick="closeDetail();showUpgrade();">Upgrade</button></div>`;
  const parentHTML = isPro
    ? `<div class="breakdown-row"><span>Parent Co.</span><span>${p.conglo ? 40 : 90}/100</span></div><div class="bar-bg"><div class="bar-fill" data-target="${p.conglo ? 40 : 90}%" style="background:${p.conglo ? 'var(--gold)' : 'var(--sage)'}"></div></div><div style="color:var(--text-dim);margin-top:6px;">Parent: <strong style="color:var(--text);">${p.parent}</strong></div>`
    : '';
  const prosHTML = p.pros && p.pros.length ? p.pros.map(i => `<li>${i}</li>`).join('') : '<li>No pros listed</li>';
  const consHTML = p.cons && p.cons.length ? p.cons.map(i => `<li>${i}</li>`).join('') : '<li>No cons listed</li>';
  sheet.innerHTML = `
    <div class="close-btn" onclick="closeDetail()">✕</div>
    <div style="font-size:0.8rem;text-transform:uppercase;color:var(--text-faint);font-weight:600;letter-spacing:0.04em;">${p.brand}</div>
    <div style="font-size:1.5rem;font-weight:700;color:var(--text);margin:2px 0 4px;">${p.name}</div>
    <div style="font-size:1.1rem;color:var(--text-dim);margin-bottom:8px;">${p.price}</div>
    <div class="review-text">${p.review}</div>
    <div class="best-for"><strong>Best for:</strong> ${p.bestFor}</div>
    <div class="pros-cons"><div class="pros"><h4>Pros</h4><ul>${prosHTML}</ul></div><div class="cons"><h4>Cons</h4><ul>${consHTML}</ul></div></div>
    <a href="${p.buyLink}" target="_blank" rel="noopener" class="buy-btn"><i class="fas fa-shopping-cart"></i> View on Amazon <span style="font-size:0.65rem; opacity:0.6;">(paid link)</span></a>
    <div style="display:flex;gap:8px;flex-wrap:wrap;margin:12px 0 16px;">
      <span style="background:rgba(155,191,143,0.06);color:var(--sage);padding:4px 14px;border-radius:30px;font-weight:700;font-size:0.75rem;">${p.cf ? '✓ Cruelty-Free' : '✗ Not CF'}</span>
      <span style="background:rgba(217,179,130,0.06);color:var(--gold);padding:4px 14px;border-radius:30px;font-weight:700;font-size:0.75rem;">${p.pkg ? 'Sustainable' : 'Non-Sust'}</span>
      <span class="region-tag">${getRegionEmoji(p.region)} ${p.region.toUpperCase()}</span>
    </div>
    <div style="font-weight:700;color:var(--text);margin-top:12px;">Ethics Score Breakdown</div>
    <div class="breakdown-row"><span>Cruelty-Free</span><span>${p.cf ? 100 : 20}/100</span></div>
    <div class="bar-bg"><div class="bar-fill" data-target="${p.cf ? 100 : 20}%" style="background:${p.cf ? 'var(--sage)' : 'var(--danger)'}"></div></div>
    <div class="breakdown-row"><span>Packaging</span><span>${p.pkg ? 85 : 40}/100</span></div>
    <div class="bar-bg"><div class="bar-fill" data-target="${p.pkg ? 85 : 40}%" style="background:${p.pkg ? 'var(--sage)' : 'var(--gold)'}"></div></div>
    ${parentHTML}${ingredientsHTML}
    <button style="width:100%;margin-top:20px;padding:16px;background:rgba(255,255,255,0.02);color:var(--text);border:1px solid var(--line);border-radius:16px;font-weight:700;cursor:pointer;" onclick="toggleRoutine(${p.id});openDetail(${p.id});">${routine.includes(p.id) ? '✓ In Routine' : '+ Add to Routine'}</button>
    <div style="font-size:0.65rem;color:var(--text-faintest);text-align:center;margin-top:12px;border-top:1px solid var(--line-soft);padding-top:12px;"><strong>As an Amazon Associate I earn from qualifying purchases.</strong></div>
  `;
  overlay.classList.add('open');
  document.body.style.overflow = 'hidden';
  setTimeout(() => { document.querySelectorAll('.bar-fill').forEach(el => { el.style.width = el.dataset.target; }); }, 100);
}

function closeDetail() {
  const overlay = document.getElementById('detailOverlay');
  if (!overlay) return;
  overlay.classList.remove('open');
  document.body.style.overflow = '';
}

function switchTab(tab) {
  const discover = document.getElementById('discoverView');
  const routineView = document.getElementById('routineView');
  if (!discover || !routineView) return;
  discover.style.display = tab === 'discover' ? 'block' : 'none';
  routineView.style.display = tab === 'routine' ? 'block' : 'none';
  document.getElementById('navDiscover').classList.toggle('active', tab === 'discover');
  document.getElementById('navRoutine').classList.toggle('active', tab === 'routine');
  if (tab === 'routine') renderRoutine();
}

/* =============================================
   PRO — honest flow.
   There is no real payment processing wired up yet.
   Replace PRO_CHECKOUT_URL with a real Stripe Payment
   Link (or other checkout URL) when ready to accept
   payment; until then this only explains the plan and
   never silently unlocks Pro for free.
   ============================================= */
const PRO_CHECKOUT_URL = null; // e.g. "https://buy.stripe.com/your_link"

function showUpgrade() {
  if (isPro) { alert('You already have Pro access on this device.'); return; }
  const overlay = document.getElementById('proModalOverlay');
  if (overlay) { overlay.classList.add('open'); document.body.style.overflow = 'hidden'; return; }
  // Fallback if the modal markup isn't on this page
  if (PRO_CHECKOUT_URL) window.open(PRO_CHECKOUT_URL, '_blank');
  else alert('Pro checkout is coming soon.');
}
function closeProModal() {
  const overlay = document.getElementById('proModalOverlay');
  if (overlay) { overlay.classList.remove('open'); document.body.style.overflow = ''; }
}
function goToCheckout() {
  if (PRO_CHECKOUT_URL) {
    window.open(PRO_CHECKOUT_URL, '_blank');
  } else {
    alert("Pro checkout isn't live yet — join the waitlist below and we'll email you the moment it opens.");
    closeProModal();
    const email = document.getElementById('emailSection');
    if (email) email.scrollIntoView({ behavior: 'smooth' });
  }
}

/* =============================================
   BARCODE SCANNER
   Uses the device camera + ZXing to actually decode
   barcodes in real time, with a manual entry fallback
   for devices without a camera or a bad scan.
   ============================================= */
async function lookupProduct(barcode) {
  try {
    const res = await fetch(`https://world.openfoodfacts.org/api/v2/product/${barcode}.json`);
    const data = await res.json();
    return data.status === 1 ? data.product : null;
  } catch (e) { return null; }
}

function calculateScore(product) {
  let s = 50;
  const labels = (product.labels || '').toLowerCase();
  const ing = (product.ingredients_text || '').toLowerCase();
  const brands = (product.brands || '').toLowerCase();
  if (labels.includes('cruelty-free') || labels.includes('vegan')) s += 20;
  if (labels.includes('organic') || labels.includes('natural')) s += 15;
  if (ing.includes('paraben') || ing.includes('sulfate')) s -= 20;
  if (brands.includes('loreal') || brands.includes('unilever') || brands.includes('p&g') || brands.includes('johnson')) s -= 15;
  return Math.min(100, Math.max(0, s));
}
function getScoreClass(s) { if (s >= 75) return 'high'; if (s >= 55) return 'mid'; return 'low'; }

let codeReader = null;
let scanning = false;
let lastScanned = null;

function initScanner() {
  const video = document.getElementById('video');
  const statusEl = document.getElementById('status');
  const scanBtn = document.getElementById('scanBtn');
  const stopBtn = document.getElementById('stopBtn');
  const spinner = document.getElementById('spinner');
  const scanFrame = document.getElementById('scanFrame');
  if (!video || !scanBtn) return; // this page has no scanner section

  async function lookupAndDisplay(barcode) {
    statusEl.textContent = '📦 Looking up...';
    spinner.classList.add('active');
    const product = await lookupProduct(barcode);
    spinner.classList.remove('active');
    const resultEl = document.getElementById('scannerResult');
    resultEl.style.display = 'block';
    if (product) {
      document.getElementById('scanBrand').textContent = product.brands || 'Unknown';
      document.getElementById('scanName').textContent = product.product_name || 'Unknown';
      const score = calculateScore(product);
      const scoreEl = document.getElementById('scanScore');
      scoreEl.textContent = score;
      scoreEl.className = 'score ' + getScoreClass(score);
      document.getElementById('scanIngredients').textContent = 'Ingredients: ' + (product.ingredients_text || 'Not available');
      const query = encodeURIComponent((product.product_name || '') + ' ' + (product.brands || ''));
      document.getElementById('scanAmazonLink').href = `https://www.amazon.com/s?k=${query}&tag=clearsourceOf-20`;
      document.getElementById('scanAmazonLink').style.display = 'inline-block';
      lastScanned = { name: product.product_name || 'Unknown', brand: product.brands || 'Unknown', score: score };
      statusEl.textContent = '✅ Found!';
    } else {
      document.getElementById('scanBrand').textContent = '❌ Not Found';
      document.getElementById('scanName').textContent = 'Not in database';
      document.getElementById('scanScore').textContent = '⚠️';
      document.getElementById('scanScore').className = 'score';
      document.getElementById('scanIngredients').textContent = 'Try another product, or enter the barcode manually.';
      document.getElementById('scanAmazonLink').style.display = 'none';
      lastScanned = null;
      statusEl.textContent = '❌ Not found';
    }
  }

  async function startScan() {
    try {
      statusEl.textContent = '📱 Starting camera...';
      scanBtn.disabled = true;
      video.style.display = 'block';
      scanFrame.classList.add('active');
      scanBtn.style.display = 'none';
      stopBtn.style.display = 'inline-block';
      scanning = true;

      if (!window.ZXingBrowser) {
        statusEl.textContent = 'Camera scanning unavailable — use manual entry below.';
        return;
      }
      codeReader = new ZXingBrowser.BrowserMultiFormatReader();
      const devices = await ZXingBrowser.BrowserCodeReader.listVideoInputDevices();
      const backCam = devices.find(d => /back|rear|environment/i.test(d.label)) || devices[devices.length - 1];
      statusEl.textContent = '🔍 Point the frame at a barcode…';

      codeReader.decodeFromVideoDevice(backCam ? backCam.deviceId : undefined, video, (result, err) => {
        if (result && scanning) {
          const barcode = result.getText();
          if (barcode && barcode !== lastScannedCode) {
            lastScannedCode = barcode;
            lookupAndDisplay(barcode);
          }
        }
      });
    } catch (err) {
      statusEl.textContent = '❌ Camera error: ' + err.message + ' — try manual entry below.';
      scanBtn.disabled = false;
      scanBtn.style.display = 'inline-block';
      stopBtn.style.display = 'none';
      scanFrame.classList.remove('active');
      spinner.classList.remove('active');
    }
  }

  let lastScannedCode = null;

  function stopScan() {
    scanning = false;
    lastScannedCode = null;
    if (codeReader) { codeReader.reset(); codeReader = null; }
    video.style.display = 'none';
    scanFrame.classList.remove('active');
    statusEl.textContent = '⏹️ Stopped. Press "Start Scan" again.';
    scanBtn.disabled = false;
    scanBtn.style.display = 'inline-block';
    stopBtn.style.display = 'none';
    spinner.classList.remove('active');
  }

  function manualEntry() {
    const barcode = prompt('Enter the barcode number printed under the bars:');
    if (barcode) lookupAndDisplay(barcode.trim());
  }

  scanBtn.addEventListener('click', startScan);
  stopBtn.addEventListener('click', stopScan);
  const manualBtn = document.getElementById('manualEntryBtn');
  if (manualBtn) manualBtn.addEventListener('click', manualEntry);
}

function getShareLink() {
  if (lastScanned) {
    const data = { name: lastScanned.name, brand: lastScanned.brand, score: lastScanned.score };
    return `https://vivugc369-ops.github.io/EthicScore/?share=${encodeURIComponent(JSON.stringify(data))}`;
  }
  return window.location.href;
}
function shareResult(platform) {
  const link = getShareLink();
  const text = `🔍 I scanned ${lastScanned ? lastScanned.name : 'a product'} on EthicScore! Score: ${lastScanned ? lastScanned.score : '?'}/100. Check your skincare too! 🌿`;
  let url = '';
  switch (platform) {
    case 'whatsapp': url = `https://api.whatsapp.com/send?text=${encodeURIComponent(text + '\n' + link)}`; break;
    case 'instagram': navigator.clipboard.writeText(link + '\n' + text); alert('📋 Link copied!'); return;
    case 'reddit': url = `https://www.reddit.com/submit?title=${encodeURIComponent('I scanned a skincare product on EthicScore!')}&url=${encodeURIComponent(link)}`; break;
  }
  if (url) window.open(url, '_blank');
}
function copyShareLink() {
  const link = getShareLink();
  navigator.clipboard.writeText(link);
  alert('📋 Link copied!');
}

/* =============================================
   INIT
   ============================================= */
document.addEventListener('DOMContentLoaded', function () {
  const searchInput = document.getElementById('searchInput');
  const regionFilter = document.getElementById('regionFilter');
  const productList = document.getElementById('productList');

  if (productList) {
    renderProducts(products, 'productList');
    if (searchInput) searchInput.addEventListener('input', () => renderProducts(filteredProducts(), 'productList'));
    if (regionFilter) regionFilter.addEventListener('change', () => renderProducts(filteredProducts(), 'productList'));
  }
  const upgradeBtn = document.getElementById('upgradeBtn');
  if (isPro && upgradeBtn) upgradeBtn.textContent = '✓ Pro';

  const detailOverlay = document.getElementById('detailOverlay');
  if (detailOverlay) detailOverlay.addEventListener('click', (e) => { if (e.target === detailOverlay) closeDetail(); });

  const proOverlay = document.getElementById('proModalOverlay');
  if (proOverlay) proOverlay.addEventListener('click', (e) => { if (e.target === proOverlay) closeProModal(); });

  initScanner();

  // Email waitlist form: if present, just let the link work (Google Form);
  // no JS submit handler needed since it's a plain link/button.
});
